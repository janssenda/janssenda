package com.dm.impulsereactor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImpulseReactorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImpulseReactorApplication.class, args);
	}
}
