/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dm.vendingmashine.servicelayer;

import com.dm.vendingmashine.dao.FileIOException;
import com.dm.vendingmashine.dao.VendingMashineInventoryDaoImpl;
import com.dm.vendingmashine.dao.VendingMashinePricingDaoImpl;
import com.dm.vendingmashine.dto.Money;
import com.dm.vendingmashine.dto.Product;
import com.dm.vendingmashine.ui.VendingMashineView;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author danimaetrix
 */
public class VendingMashineServiceImpl {

    VendingMashinePricingDaoImpl daoPrices;
    VendingMashineInventoryDaoImpl daoInv;
    Map inventory, pricing;

    public VendingMashineServiceImpl() throws FileIOException {
        this.daoPrices = new VendingMashinePricingDaoImpl();
        this.daoInv = new VendingMashineInventoryDaoImpl();
        this.pricing = daoPrices.loadPricingFromFile("priceData.csv");
        this.inventory = daoInv.readInventoryFromFile("inventoryData.csv");
    }

    // Testing method
    public void vtesting() throws FileIOException {

        VendingMashineView view = new VendingMashineView();
        
        view.generateMenu(returnPriceArrayWithStatus());
        /*
        System.out.println("Qty of Dasani: " + daoInv.getProductQuantity("Dasani"));
        for (int i = 0; i < 12; i++) {
            daoInv.vendItem("Dasani");
        }
        System.out.println("Qty of Dasani: " + daoInv.getProductQuantity("Dasani"));
        daoInv.writeInventoryToFile("output.csv");
*/
    }

    // Returns the simple pricemap // not currently needed
    public Map<String, String> returnPriceMap() {
        return pricing;    }

    
    
    // Builds the arraylist for dynamic main menu.  Must be located in service layer
    // because it needs access to BOTH dao implementations
    public List<String[]> returnPriceArrayWithStatus() {
        List<String[]> priceList = new ArrayList<>();
        Set<String> brands = pricing.keySet();
        brands.stream().forEach(name -> {
            String[] currentString = new String[3];
            currentString[0] = name;
            currentString[1] = (String) pricing.get(name);
            if (isSoldOut(name)) {
                currentString[2] = "<Sold Out>";
            } else {
                currentString[2] = "";
            }            
            priceList.add(currentString);
        });
        return priceList;
    }
    
    public Product getProduct(String productName){
        return daoInv.getProduct(productName);
    }
    
    public Product vendProduct(String productName){        
        return daoInv.vendItem(productName);        
    }

    // Simply queries the dao to check on item availability.  Returns true if sold out.
    public boolean isSoldOut(String productName) {
        return (daoInv.getProductQuantity(productName) == 0);
    }

    // We compare the big decimal values of the money object and the price
    // and return true if the money is >= the price, and false otherwise
    public boolean validateMoney(Money m, String productName) {
        BigDecimal cost = new BigDecimal((String) pricing.get(productName));
        return (m.getTotalmoney().compareTo(cost) >= 0);
    }

    // Computes the change for user.  The change in available funds is computed via
    // big decimal methods to retain accuracy.  The physical change, however, must be rounded
    // to two decimal places so it can be broken down to US denominations evenly.
    // Since prices and paymnent are in the form of two decmial place doubles anyways,
    // the "rounding" that takes place here actually does nothing but is included
    // for completeness (i.e., we could charge fractional cents on top of items if we 
    // really wanted to, without requiring any code modification.    
    public Money calculateChange(Money m, String name) {

        String price = (String) pricing.get(name);
        BigDecimal bigPrice = new BigDecimal(price);
        
        m.setTotalmoney(m.getTotalmoney().subtract(bigPrice));

        int total = m.getTotalmoney().setScale(2, RoundingMode.HALF_UP)
                .movePointRight(2).intValue();

        m.setQuarters(total / 25);
        total = total - 25 * m.getQuarters();
        m.setDimes(total / 10);
        total = total - 10 * m.getDimes();
        m.setNickels(total / 5);
        m.setPennies(total - 5 * m.getNickels());

        return m;
    }
    
    
    public void updateInventory() throws FileIOException {
        daoInv.writeInventoryToFile("output.csv");
    }
}
