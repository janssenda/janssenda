/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dm.vendingmashine.controller;

import com.dm.vendingmashine.dao.FileIOException;
import com.dm.vendingmashine.dto.Money;
import com.dm.vendingmashine.servicelayer.VendingMashineServiceImpl;
import com.dm.vendingmashine.ui.VendingMashineView;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author danimaetrix
 */
public class VendingMashineController {

    private final Money userMoney;

    // Dependency Injection
    VendingMashineServiceImpl service;
    VendingMashineView view;

    //service.vtesting ();
    public VendingMashineController() throws FileIOException {
        this.service = new VendingMashineServiceImpl();
        this.view = new VendingMashineView();
        this.userMoney = new Money(BigDecimal.valueOf(0));
    }

    // Main program loop
    public void run() throws FileIOException {
        boolean repeat = true;

        while (repeat) {
            switch (getUserAction(userMoney)) {
                case 0:
                    repeat = false;
                    break;
                case 1:
                    view.userAddMoney(userMoney);
                    break;
                case 2:
                    drinkMenuSelection(userMoney);
                    break;
            }
        }
        view.showChange(userMoney);
        service.updateInventory();
        exitProgram();
    }

    // End main program loop
    // Main drink menu screen
    private void drinkMenuSelection(Money userMoney) {
        boolean repeat = true;

        List<String[]> priceList = service.returnPriceArrayWithStatus();
        view.generateMenu(priceList);

        while (repeat) {
            int choice = view.getUserDrinkSelection(userMoney, priceList.size());

            if (choice == 0) {
                return;
            }
            String name = priceList.get(choice - 1)[0];
            if (service.isSoldOut(name)) {
                view.soldOutBanner();
            } else if (!service.validateMoney(userMoney, name)) {
                view.insufficientFundsBanner();
            } else {
                view.showTheProduct(service.getProduct(name));
                service.vendProduct(name);
                userMoney = service.calculateChange(userMoney, name);
            }

        }
    }

    private int getUserAction(Money userMoney) {
        view.generateMenuNoIndex(service.returnPriceArrayWithStatus());
        return view.userActionMenu(userMoney);
    }

    private void exitProgram() {
        view.showExitMessage();
    }

}
