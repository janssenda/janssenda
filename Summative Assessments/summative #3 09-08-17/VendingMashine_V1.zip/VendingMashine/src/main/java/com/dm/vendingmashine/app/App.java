/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dm.vendingmashine.app;

import com.dm.vendingmashine.controller.VendingMashineController;
import com.dm.vendingmashine.dao.FileIOException;

/**
 *
 * @author danimaetrix
 */
public class App {

    public static void main(String[] args) throws FileIOException {

        
        VendingMashineController controller = new VendingMashineController();
        
        controller.run();



        /*
        Iterator it = myInventory.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            //System.out.println(pair.getKey() + " = " + pair.getValue());

            it.remove(); // avoids a ConcurrentModificationException
        }
         
        Set<String> brands = myInventory.keySet();

        brands.stream()
                .forEach(name -> {

                    System.out.println("=================================");
                    System.out.println("Brand: " + name);

                    List<Product> l = (ArrayList) myInventory.get(name);

                    for (int i = 0; i < l.size(); i++) {
                        System.out.print(l.get(i).getBestBy().toString()
                                + " " + l.get(i).getMessage() + "\n");
                    }

                });

/*
        brands.stream()
                .forEach(name -> {

                    System.out.println("=================================");
                    System.out.println("Brand: " + name);

                    List<Product> l = (ArrayList) myInventory.get(name);

                    l.stream().forEach(p -> {
                        System.out.println(p.getProductName());
                    
                    });

                });

        //stream().forEach(s -> System.out.println(s.getName())
    }
         */
    }
}
