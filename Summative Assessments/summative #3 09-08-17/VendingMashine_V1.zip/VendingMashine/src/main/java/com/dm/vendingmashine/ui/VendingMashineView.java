/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dm.vendingmashine.ui;

import com.dm.vendingmashine.dto.Money;
import com.dm.vendingmashine.dto.Product;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 *
 * @author Danimaetrix
 */
public class VendingMashineView {

    UserIo io;

    public VendingMashineView() {
        this.io = new UserIoConsoleImpl();
    }

    public void showChange(Money userMoney) {
        io.print("");
        io.print("Total change: $" + userMoney.getTotalmoney().toString());
        io.print("Quarters: " + userMoney.getQuarters());
        io.print("Dimes: " + userMoney.getDimes());
        io.print("Nickels: " + userMoney.getNickels());
        io.print("Pennies: " + userMoney.getPennies());
    }

    public void generateMenu(List<String[]> pricing) {

        io.print("");
        for (int i = 0; i < pricing.size(); i++) {
            io.print(i + 1 + ". " + stShort(pricing.get(i)[0], 15)
                    + stShort(pricing.get(i)[1], 6)
                    + pricing.get(i)[2]);
        }
        io.print("0. Back");
        io.print("");

    }

    public void generateMenuNoIndex(List<String[]> pricing) {

        io.print("");
        for (int i = 0; i < pricing.size(); i++) {
            io.print(stShort(pricing.get(i)[0], 15)
                    + stShort(pricing.get(i)[1], 6)
                    + pricing.get(i)[2]);
        }
        io.print("");

    }

    // Short method to shorten and extend string to length l, using "..." to truncate 
    // and whitespace to extend.  Used to format fields for output to user in printAllTitles
    public String stShort(String string, int l) {
        //int l = 18;
        char[] newstr = new char[l];

        if (string.length() > l) {
            char[] str = string.toCharArray();
            System.arraycopy(str, 0, newstr, 0, l - 3);

            for (int i = 0; i < 3; i++) {
                newstr[(l - 4) + i] = '.';
            }

            String fstring = new String(newstr);
            return fstring;

        } else {
            char[] str = string.toCharArray();
            System.arraycopy(str, 0, newstr, 0, str.length);

            for (int i = str.length + 1; i < l; i++) {
                newstr[i] = ' ';

            }
            String fstring = new String(newstr);
            return fstring;
        }
    }
    
    public void showTheProduct(Product p){
        io.print("");
        io.print("Congrats on your brand new "+p.getProductName());
        io.print("Please enjoy by: "
                +p.getBestBy().format(DateTimeFormatter.ofPattern("MM/dd/yyyy")) 
                + "for maximum freshness!");
        io.print(p.getMessage());    }

    public Money userAddMoney(Money userMoney) {
        userAddMoneyBanner();
        io.print("You currently have: $" + userMoney.getTotalmoney().toString());
        BigDecimal added = io.readBigDecimal("How much would you like to add ($)? ");

        userMoney.setTotalmoney(userMoney.getTotalmoney().add(added));
        userMoney.breakMoney(userMoney.getTotalmoney());

        return userMoney;
    }

    public int userActionMenu(Money userMoney) {
        int choice;
        io.print("You currently have: $" + userMoney.getTotalmoney().toString());
        io.print("What would you like to do? ");
        io.print("1. Add money");

        if (userMoney.getTotalmoney().compareTo(BigDecimal.ZERO) > 0) {
            io.print("2. Make a selection");
            io.print("0. Return change and walk away");
            choice = io.readInt(">> ", 0, 2);
        } else {
            io.print("0. Return change and walk away");
            choice = io.readInt(">> ", 0, 1);

        }
        return choice;
    }

    public int getUserDrinkSelection(Money userMoney, int range) {
        io.print("You currently have: " + userMoney.getTotalmoney().toString());
        return io.readInt("Please select a drink: ", 0, range);
    }

    public void userAddMoneyBanner() {
        io.print("\n");
        io.print(" *** Add Money ***");
    }

    public void insufficientFundsBanner() {
        io.print("\n");
        io.print(" *** Insufficient Funds... add money ***");
    }

    public void soldOutBanner() {
        io.print("");
        io.print(" *** Sorry, sold out! Please try another... ***");
        io.print("\n");

    }

    public void drinkSelectionBanner() {
        io.print("\n");
        io.print(" *** Drink Selection ***");
    }

// Additional user messages
    public void showExitMessage() {
        io.print("\n");
        io.print("GOODBYE!!");
        io.print("\n");
    }

}
