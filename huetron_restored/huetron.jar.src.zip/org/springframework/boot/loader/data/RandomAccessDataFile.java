/*     */ package org.springframework.boot.loader.data;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomAccessDataFile
/*     */   implements RandomAccessData
/*     */ {
/*     */   private final FileAccess fileAccess;
/*     */   private final long offset;
/*     */   private final long length;
/*     */   
/*     */   public RandomAccessDataFile(File file)
/*     */   {
/*  45 */     if (file == null) {
/*  46 */       throw new IllegalArgumentException("File must not be null");
/*     */     }
/*  48 */     this.fileAccess = new FileAccess(file, null);
/*  49 */     this.offset = 0L;
/*  50 */     this.length = file.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RandomAccessDataFile(FileAccess fileAccess, long offset, long length)
/*     */   {
/*  60 */     this.offset = offset;
/*  61 */     this.length = length;
/*  62 */     this.fileAccess = fileAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getFile()
/*     */   {
/*  70 */     return this.fileAccess.file;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/*  75 */     return new DataInputStream(null);
/*     */   }
/*     */   
/*     */   public RandomAccessData getSubsection(long offset, long length)
/*     */   {
/*  80 */     if ((offset < 0L) || (length < 0L) || (offset + length > this.length)) {
/*  81 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  83 */     return new RandomAccessDataFile(this.fileAccess, this.offset + offset, length);
/*     */   }
/*     */   
/*     */   public byte[] read() throws IOException
/*     */   {
/*  88 */     return read(0L, this.length);
/*     */   }
/*     */   
/*     */   public byte[] read(long offset, long length) throws IOException
/*     */   {
/*  93 */     byte[] bytes = new byte[(int)length];
/*  94 */     read(bytes, offset, 0, bytes.length);
/*  95 */     return bytes;
/*     */   }
/*     */   
/*     */   private int readByte(long position) throws IOException {
/*  99 */     if (position >= this.length) {
/* 100 */       return -1;
/*     */     }
/* 102 */     return this.fileAccess.readByte(this.offset + position);
/*     */   }
/*     */   
/*     */   private int read(byte[] bytes, long position, int offset, int length) throws IOException
/*     */   {
/* 107 */     if (position > this.length) {
/* 108 */       return -1;
/*     */     }
/* 110 */     return this.fileAccess.read(bytes, this.offset + position, offset, length);
/*     */   }
/*     */   
/*     */   public long getSize()
/*     */   {
/* 115 */     return this.length;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 119 */     this.fileAccess.close();
/*     */   }
/*     */   
/*     */   private class DataInputStream
/*     */     extends InputStream
/*     */   {
/*     */     private int position;
/*     */     
/*     */     private DataInputStream() {}
/*     */     
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 132 */       int read = RandomAccessDataFile.this.readByte(this.position);
/* 133 */       if (read > -1) {
/* 134 */         moveOn(1);
/*     */       }
/* 136 */       return read;
/*     */     }
/*     */     
/*     */     public int read(byte[] b) throws IOException
/*     */     {
/* 141 */       return read(b, 0, b == null ? 0 : b.length);
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 146 */       if (b == null) {
/* 147 */         throw new NullPointerException("Bytes must not be null");
/*     */       }
/* 149 */       return doRead(b, off, len);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int doRead(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 162 */       if (len == 0) {
/* 163 */         return 0;
/*     */       }
/* 165 */       int cappedLen = cap(len);
/* 166 */       if (cappedLen <= 0) {
/* 167 */         return -1;
/*     */       }
/* 169 */       return (int)moveOn(RandomAccessDataFile.this
/* 170 */         .read(b, this.position, off, cappedLen));
/*     */     }
/*     */     
/*     */     public long skip(long n) throws IOException
/*     */     {
/* 175 */       return n <= 0L ? 0L : moveOn(cap(n));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int cap(long n)
/*     */     {
/* 185 */       return (int)Math.min(RandomAccessDataFile.this.length - this.position, n);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private long moveOn(int amount)
/*     */     {
/* 194 */       this.position += amount;
/* 195 */       return amount;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class FileAccess
/*     */   {
/* 202 */     private final Object monitor = new Object();
/*     */     
/*     */     private final File file;
/*     */     private RandomAccessFile randomAccessFile;
/*     */     
/*     */     private FileAccess(File file)
/*     */     {
/* 209 */       this.file = file;
/* 210 */       openIfNecessary();
/*     */     }
/*     */     
/*     */     private int read(byte[] bytes, long position, int offset, int length) throws IOException
/*     */     {
/* 215 */       synchronized (this.monitor) {
/* 216 */         openIfNecessary();
/* 217 */         this.randomAccessFile.seek(position);
/* 218 */         return this.randomAccessFile.read(bytes, offset, length);
/*     */       }
/*     */     }
/*     */     
/*     */     private void openIfNecessary() {
/* 223 */       if (this.randomAccessFile == null) {
/*     */         try {
/* 225 */           this.randomAccessFile = new RandomAccessFile(this.file, "r");
/*     */         }
/*     */         catch (FileNotFoundException ex) {
/* 228 */           throw new IllegalArgumentException(String.format("File %s must exist", new Object[] {this.file
/* 229 */             .getAbsolutePath() }));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void close() throws IOException {
/* 235 */       synchronized (this.monitor) {
/* 236 */         if (this.randomAccessFile != null) {
/* 237 */           this.randomAccessFile.close();
/* 238 */           this.randomAccessFile = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private int readByte(long position) throws IOException {
/* 244 */       synchronized (this.monitor) {
/* 245 */         openIfNecessary();
/* 246 */         this.randomAccessFile.seek(position);
/* 247 */         return this.randomAccessFile.read();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\org\springframework\boot\loader\data\RandomAccessDataFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */