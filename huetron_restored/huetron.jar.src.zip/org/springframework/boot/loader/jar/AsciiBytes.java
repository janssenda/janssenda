/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AsciiBytes
/*     */ {
/*     */   private static final String EMPTY_STRING = "";
/*  32 */   private static final int[] INITIAL_BYTE_BITMASK = { 127, 31, 15, 7 };
/*     */   
/*     */ 
/*     */   private static final int SUBSEQUENT_BYTE_BITMASK = 63;
/*     */   
/*     */ 
/*     */   private final byte[] bytes;
/*     */   
/*     */   private final int offset;
/*     */   
/*     */   private final int length;
/*     */   
/*     */   private String string;
/*     */   
/*     */   private int hash;
/*     */   
/*     */ 
/*     */   AsciiBytes(String string)
/*     */   {
/*  51 */     this(string.getBytes(StandardCharsets.UTF_8));
/*  52 */     this.string = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   AsciiBytes(byte[] bytes)
/*     */   {
/*  61 */     this(bytes, 0, bytes.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   AsciiBytes(byte[] bytes, int offset, int length)
/*     */   {
/*  72 */     if ((offset < 0) || (length < 0) || (offset + length > bytes.length)) {
/*  73 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  75 */     this.bytes = bytes;
/*  76 */     this.offset = offset;
/*  77 */     this.length = length;
/*     */   }
/*     */   
/*     */   public int length() {
/*  81 */     return this.length;
/*     */   }
/*     */   
/*     */   public boolean startsWith(AsciiBytes prefix) {
/*  85 */     if (this == prefix) {
/*  86 */       return true;
/*     */     }
/*  88 */     if (prefix.length > this.length) {
/*  89 */       return false;
/*     */     }
/*  91 */     for (int i = 0; i < prefix.length; i++) {
/*  92 */       if (this.bytes[(i + this.offset)] != prefix.bytes[(i + prefix.offset)]) {
/*  93 */         return false;
/*     */       }
/*     */     }
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   public boolean endsWith(AsciiBytes postfix) {
/* 100 */     if (this == postfix) {
/* 101 */       return true;
/*     */     }
/* 103 */     if (postfix.length > this.length) {
/* 104 */       return false;
/*     */     }
/* 106 */     for (int i = 0; i < postfix.length; i++) {
/* 107 */       if (this.bytes[(this.offset + (this.length - 1) - i)] != postfix.bytes[(postfix.offset + (postfix.length - 1) - i)])
/*     */       {
/* 109 */         return false;
/*     */       }
/*     */     }
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   public AsciiBytes substring(int beginIndex) {
/* 116 */     return substring(beginIndex, this.length);
/*     */   }
/*     */   
/*     */   public AsciiBytes substring(int beginIndex, int endIndex) {
/* 120 */     int length = endIndex - beginIndex;
/* 121 */     if (this.offset + length > this.bytes.length) {
/* 122 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 124 */     return new AsciiBytes(this.bytes, this.offset + beginIndex, length);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 129 */     if (this.string == null) {
/* 130 */       if (this.length == 0) {
/* 131 */         this.string = "";
/*     */       }
/*     */       else {
/* 134 */         this.string = new String(this.bytes, this.offset, this.length, StandardCharsets.UTF_8);
/*     */       }
/*     */     }
/*     */     
/* 138 */     return this.string;
/*     */   }
/*     */   
/*     */   public boolean matches(CharSequence name, char suffix) {
/* 142 */     int charIndex = 0;
/* 143 */     int nameLen = name.length();
/* 144 */     int totalLen = nameLen + (suffix == 0 ? 0 : 1);
/* 145 */     for (int i = this.offset; i < this.offset + this.length; i++) {
/* 146 */       int b = this.bytes[i];
/* 147 */       int remainingUtfBytes = getNumberOfUtfBytes(b) - 1;
/* 148 */       b &= INITIAL_BYTE_BITMASK[remainingUtfBytes];
/* 149 */       for (int j = 0; j < remainingUtfBytes; j++) {
/* 150 */         b = (b << 6) + (this.bytes[(++i)] & 0x3F);
/*     */       }
/* 152 */       char c = getChar(name, suffix, charIndex++);
/* 153 */       if (b <= 65535) {
/* 154 */         if (c != b) {
/* 155 */           return false;
/*     */         }
/*     */       }
/*     */       else {
/* 159 */         if (c != (b >> 10) + 55232) {
/* 160 */           return false;
/*     */         }
/* 162 */         c = getChar(name, suffix, charIndex++);
/* 163 */         if (c != (b & 0x3FF) + 56320) {
/* 164 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 168 */     return charIndex == totalLen;
/*     */   }
/*     */   
/*     */   private char getChar(CharSequence name, char suffix, int index) {
/* 172 */     if (index < name.length()) {
/* 173 */       return name.charAt(index);
/*     */     }
/* 175 */     if (index == name.length()) {
/* 176 */       return suffix;
/*     */     }
/* 178 */     return '\000';
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 183 */     int hash = this.hash;
/* 184 */     if ((hash == 0) && (this.bytes.length > 0)) {
/* 185 */       for (int i = this.offset; i < this.offset + this.length; i++) {
/* 186 */         int b = this.bytes[i];
/* 187 */         int remainingUtfBytes = getNumberOfUtfBytes(b) - 1;
/* 188 */         b &= INITIAL_BYTE_BITMASK[remainingUtfBytes];
/* 189 */         for (int j = 0; j < remainingUtfBytes; j++) {
/* 190 */           b = (b << 6) + (this.bytes[(++i)] & 0x3F);
/*     */         }
/* 192 */         if (b <= 65535) {
/* 193 */           hash = 31 * hash + b;
/*     */         }
/*     */         else {
/* 196 */           hash = 31 * hash + ((b >> 10) + 55232);
/* 197 */           hash = 31 * hash + ((b & 0x3FF) + 56320);
/*     */         }
/*     */       }
/* 200 */       this.hash = hash;
/*     */     }
/* 202 */     return hash;
/*     */   }
/*     */   
/*     */   private int getNumberOfUtfBytes(int b) {
/* 206 */     if ((b & 0x80) == 0) {
/* 207 */       return 1;
/*     */     }
/* 209 */     int numberOfUtfBytes = 0;
/* 210 */     while ((b & 0x80) != 0) {
/* 211 */       b <<= 1;
/* 212 */       numberOfUtfBytes++;
/*     */     }
/* 214 */     return numberOfUtfBytes;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 219 */     if (obj == null) {
/* 220 */       return false;
/*     */     }
/* 222 */     if (this == obj) {
/* 223 */       return true;
/*     */     }
/* 225 */     if (obj.getClass() == AsciiBytes.class) {
/* 226 */       AsciiBytes other = (AsciiBytes)obj;
/* 227 */       if (this.length == other.length) {
/* 228 */         for (int i = 0; i < this.length; i++) {
/* 229 */           if (this.bytes[(this.offset + i)] != other.bytes[(other.offset + i)]) {
/* 230 */             return false;
/*     */           }
/*     */         }
/* 233 */         return true;
/*     */       }
/*     */     }
/* 236 */     return false;
/*     */   }
/*     */   
/*     */   static String toString(byte[] bytes) {
/* 240 */     return new String(bytes, StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   public static int hashCode(CharSequence charSequence)
/*     */   {
/* 245 */     if ((charSequence instanceof StringSequence))
/*     */     {
/* 247 */       return charSequence.hashCode();
/*     */     }
/* 249 */     return charSequence.toString().hashCode();
/*     */   }
/*     */   
/*     */   public static int hashCode(int hash, char suffix) {
/* 253 */     return suffix == 0 ? hash : 31 * hash + suffix;
/*     */   }
/*     */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\org\springframework\boot\loader\jar\AsciiBytes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */