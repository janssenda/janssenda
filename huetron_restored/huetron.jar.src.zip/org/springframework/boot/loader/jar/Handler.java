/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends URLStreamHandler
/*     */ {
/*     */   private static final String JAR_PROTOCOL = "jar:";
/*     */   private static final String FILE_PROTOCOL = "file:";
/*     */   private static final String SEPARATOR = "!/";
/*     */   private static final String CURRENT_DIR = "/./";
/*  54 */   private static final Pattern CURRENT_DIR_PATTERN = Pattern.compile("/./");
/*     */   
/*     */   private static final String PARENT_DIR = "/../";
/*     */   
/*  58 */   private static final String[] FALLBACK_HANDLERS = { "sun.net.www.protocol.jar.Handler" };
/*     */   
/*     */   private static final Method OPEN_CONNECTION_METHOD;
/*     */   
/*     */   static
/*     */   {
/*  64 */     Method method = null;
/*     */     try {
/*  66 */       method = URLStreamHandler.class.getDeclaredMethod("openConnection", new Class[] { URL.class });
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*  72 */     OPEN_CONNECTION_METHOD = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private static SoftReference<Map<File, JarFile>> rootFileCache = new SoftReference(null);
/*     */   
/*     */   private final JarFile jarFile;
/*     */   
/*     */   private URLStreamHandler fallbackHandler;
/*     */   
/*     */   public Handler()
/*     */   {
/*  86 */     this(null);
/*     */   }
/*     */   
/*     */   public Handler(JarFile jarFile) {
/*  90 */     this.jarFile = jarFile;
/*     */   }
/*     */   
/*     */   protected URLConnection openConnection(URL url) throws IOException
/*     */   {
/*  95 */     if ((this.jarFile != null) && 
/*  96 */       (url.toString().startsWith(this.jarFile.getUrl().toString()))) {
/*  97 */       return JarURLConnection.get(url, this.jarFile);
/*     */     }
/*     */     try {
/* 100 */       return JarURLConnection.get(url, getRootJarFileFromUrl(url));
/*     */     }
/*     */     catch (Exception ex) {
/* 103 */       return openFallbackConnection(url, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private URLConnection openFallbackConnection(URL url, Exception reason) throws IOException
/*     */   {
/*     */     try {
/* 110 */       return openConnection(getFallbackHandler(), url);
/*     */     }
/*     */     catch (Exception ex) {
/* 113 */       if ((reason instanceof IOException)) {
/* 114 */         log(false, "Unable to open fallback handler", ex);
/* 115 */         throw ((IOException)reason);
/*     */       }
/* 117 */       log(true, "Unable to open fallback handler", ex);
/* 118 */       if ((reason instanceof RuntimeException)) {
/* 119 */         throw ((RuntimeException)reason);
/*     */       }
/* 121 */       throw new IllegalStateException(reason);
/*     */     }
/*     */   }
/*     */   
/*     */   private void log(boolean warning, String message, Exception cause)
/*     */   {
/*     */     try {
/* 128 */       Logger.getLogger(getClass().getName()).log(warning ? Level.WARNING : Level.FINEST, message, cause);
/*     */     }
/*     */     catch (Exception ex) {
/* 131 */       if (warning) {
/* 132 */         System.err.println("WARNING: " + message);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private URLStreamHandler getFallbackHandler() {
/* 138 */     if (this.fallbackHandler != null) {
/* 139 */       return this.fallbackHandler;
/*     */     }
/* 141 */     for (String handlerClassName : FALLBACK_HANDLERS) {
/*     */       try {
/* 143 */         Class<?> handlerClass = Class.forName(handlerClassName);
/* 144 */         this.fallbackHandler = ((URLStreamHandler)handlerClass.newInstance());
/* 145 */         return this.fallbackHandler;
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/*     */ 
/* 151 */     throw new IllegalStateException("Unable to find fallback handler");
/*     */   }
/*     */   
/*     */   private URLConnection openConnection(URLStreamHandler handler, URL url) throws Exception
/*     */   {
/* 156 */     if (OPEN_CONNECTION_METHOD == null) {
/* 157 */       throw new IllegalStateException("Unable to invoke fallback open connection method");
/*     */     }
/*     */     
/* 160 */     OPEN_CONNECTION_METHOD.setAccessible(true);
/* 161 */     return (URLConnection)OPEN_CONNECTION_METHOD.invoke(handler, new Object[] { url });
/*     */   }
/*     */   
/*     */   protected void parseURL(URL context, String spec, int start, int limit)
/*     */   {
/* 166 */     if (spec.regionMatches(true, 0, "jar:", 0, "jar:".length())) {
/* 167 */       setFile(context, getFileFromSpec(spec.substring(start, limit)));
/*     */     }
/*     */     else {
/* 170 */       setFile(context, getFileFromContext(context, spec.substring(start, limit)));
/*     */     }
/*     */   }
/*     */   
/*     */   private String getFileFromSpec(String spec) {
/* 175 */     int separatorIndex = spec.lastIndexOf("!/");
/* 176 */     if (separatorIndex == -1) {
/* 177 */       throw new IllegalArgumentException("No !/ in spec '" + spec + "'");
/*     */     }
/*     */     try {
/* 180 */       new URL(spec.substring(0, separatorIndex));
/* 181 */       return spec;
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 184 */       throw new IllegalArgumentException("Invalid spec URL '" + spec + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getFileFromContext(URL context, String spec) {
/* 189 */     String file = context.getFile();
/* 190 */     if (spec.startsWith("/")) {
/* 191 */       return trimToJarRoot(file) + "!/" + spec.substring(1);
/*     */     }
/* 193 */     if (file.endsWith("/")) {
/* 194 */       return file + spec;
/*     */     }
/* 196 */     int lastSlashIndex = file.lastIndexOf('/');
/* 197 */     if (lastSlashIndex == -1) {
/* 198 */       throw new IllegalArgumentException("No / found in context URL's file '" + file + "'");
/*     */     }
/*     */     
/* 201 */     return file.substring(0, lastSlashIndex + 1) + spec;
/*     */   }
/*     */   
/*     */   private String trimToJarRoot(String file) {
/* 205 */     int lastSeparatorIndex = file.lastIndexOf("!/");
/* 206 */     if (lastSeparatorIndex == -1) {
/* 207 */       throw new IllegalArgumentException("No !/ found in context URL's file '" + file + "'");
/*     */     }
/*     */     
/* 210 */     return file.substring(0, lastSeparatorIndex);
/*     */   }
/*     */   
/*     */   private void setFile(URL context, String file) {
/* 214 */     setURL(context, "jar:", null, -1, null, null, normalize(file), null, null);
/*     */   }
/*     */   
/*     */   private String normalize(String file) {
/* 218 */     if ((!file.contains("/./")) && (!file.contains("/../"))) {
/* 219 */       return file;
/*     */     }
/* 221 */     int afterLastSeparatorIndex = file.lastIndexOf("!/") + "!/".length();
/* 222 */     String afterSeparator = file.substring(afterLastSeparatorIndex);
/* 223 */     afterSeparator = replaceParentDir(afterSeparator);
/* 224 */     afterSeparator = replaceCurrentDir(afterSeparator);
/* 225 */     return file.substring(0, afterLastSeparatorIndex) + afterSeparator;
/*     */   }
/*     */   
/*     */   private String replaceParentDir(String file) {
/*     */     int parentDirIndex;
/* 230 */     while ((parentDirIndex = file.indexOf("/../")) >= 0) {
/* 231 */       int precedingSlashIndex = file.lastIndexOf('/', parentDirIndex - 1);
/* 232 */       if (precedingSlashIndex >= 0)
/*     */       {
/* 234 */         file = file.substring(0, precedingSlashIndex) + file.substring(parentDirIndex + 3);
/*     */       }
/*     */       else {
/* 237 */         file = file.substring(parentDirIndex + 4);
/*     */       }
/*     */     }
/* 240 */     return file;
/*     */   }
/*     */   
/*     */   private String replaceCurrentDir(String file) {
/* 244 */     return CURRENT_DIR_PATTERN.matcher(file).replaceAll("/");
/*     */   }
/*     */   
/*     */   protected int hashCode(URL u)
/*     */   {
/* 249 */     return hashCode(u.getProtocol(), u.getFile());
/*     */   }
/*     */   
/*     */   private int hashCode(String protocol, String file) {
/* 253 */     int result = protocol == null ? 0 : protocol.hashCode();
/* 254 */     int separatorIndex = file.indexOf("!/");
/* 255 */     if (separatorIndex == -1) {
/* 256 */       return result + file.hashCode();
/*     */     }
/* 258 */     String source = file.substring(0, separatorIndex);
/* 259 */     String entry = canonicalize(file.substring(separatorIndex + 2));
/*     */     try {
/* 261 */       result += new URL(source).hashCode();
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 264 */       result += source.hashCode();
/*     */     }
/* 266 */     result += entry.hashCode();
/* 267 */     return result;
/*     */   }
/*     */   
/*     */   protected boolean sameFile(URL u1, URL u2)
/*     */   {
/* 272 */     if ((!u1.getProtocol().equals("jar")) || (!u2.getProtocol().equals("jar"))) {
/* 273 */       return false;
/*     */     }
/* 275 */     int separator1 = u1.getFile().indexOf("!/");
/* 276 */     int separator2 = u2.getFile().indexOf("!/");
/* 277 */     if ((separator1 == -1) || (separator2 == -1)) {
/* 278 */       return super.sameFile(u1, u2);
/*     */     }
/* 280 */     String nested1 = u1.getFile().substring(separator1 + "!/".length());
/* 281 */     String nested2 = u2.getFile().substring(separator2 + "!/".length());
/* 282 */     if (!nested1.equals(nested2)) {
/* 283 */       String canonical1 = canonicalize(nested1);
/* 284 */       String canonical2 = canonicalize(nested2);
/* 285 */       if (!canonical1.equals(canonical2)) {
/* 286 */         return false;
/*     */       }
/*     */     }
/* 289 */     String root1 = u1.getFile().substring(0, separator1);
/* 290 */     String root2 = u2.getFile().substring(0, separator2);
/*     */     try {
/* 292 */       return super.sameFile(new URL(root1), new URL(root2));
/*     */     }
/*     */     catch (MalformedURLException localMalformedURLException) {}
/*     */     
/*     */ 
/* 297 */     return super.sameFile(u1, u2);
/*     */   }
/*     */   
/*     */   private String canonicalize(String path) {
/* 301 */     return path.replace("!/", "/");
/*     */   }
/*     */   
/*     */   public JarFile getRootJarFileFromUrl(URL url) throws IOException {
/* 305 */     String spec = url.getFile();
/* 306 */     int separatorIndex = spec.indexOf("!/");
/* 307 */     if (separatorIndex == -1) {
/* 308 */       throw new MalformedURLException("Jar URL does not contain !/ separator");
/*     */     }
/* 310 */     String name = spec.substring(0, separatorIndex);
/* 311 */     return getRootJarFile(name);
/*     */   }
/*     */   
/*     */   private JarFile getRootJarFile(String name) throws IOException {
/*     */     try {
/* 316 */       if (!name.startsWith("file:")) {
/* 317 */         throw new IllegalStateException("Not a file URL");
/*     */       }
/* 319 */       String path = name.substring("file:".length());
/* 320 */       File file = new File(URLDecoder.decode(path, "UTF-8"));
/* 321 */       Map<File, JarFile> cache = (Map)rootFileCache.get();
/* 322 */       JarFile result = cache == null ? null : (JarFile)cache.get(file);
/* 323 */       if (result == null) {
/* 324 */         result = new JarFile(file);
/* 325 */         addToRootFileCache(file, result);
/*     */       }
/* 327 */       return result;
/*     */     }
/*     */     catch (Exception ex) {
/* 330 */       throw new IOException("Unable to open root Jar file '" + name + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void addToRootFileCache(File sourceFile, JarFile jarFile)
/*     */   {
/* 340 */     Map<File, JarFile> cache = (Map)rootFileCache.get();
/* 341 */     if (cache == null) {
/* 342 */       cache = new ConcurrentHashMap();
/* 343 */       rootFileCache = new SoftReference(cache);
/*     */     }
/* 345 */     cache.put(sourceFile, jarFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setUseFastConnectionExceptions(boolean useFastConnectionExceptions)
/*     */   {
/* 356 */     JarURLConnection.setUseFastExceptions(useFastConnectionExceptions);
/*     */   }
/*     */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\org\springframework\boot\loader\jar\Handler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */