package org.springframework.boot.loader.jar;

abstract interface JarEntryFilter
{
  public abstract AsciiBytes apply(AsciiBytes paramAsciiBytes);
}


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\org\springframework\boot\loader\jar\JarEntryFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */