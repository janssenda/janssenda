/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilePermission;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.security.Permission;
/*     */ import org.springframework.boot.loader.data.RandomAccessData;
/*     */ import org.springframework.boot.loader.data.RandomAccessDataFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JarURLConnection
/*     */   extends java.net.JarURLConnection
/*     */ {
/*  41 */   private static ThreadLocal<Boolean> useFastExceptions = new ThreadLocal();
/*     */   
/*  43 */   private static final FileNotFoundException FILE_NOT_FOUND_EXCEPTION = new FileNotFoundException("Jar file or entry not found");
/*     */   
/*     */ 
/*  46 */   private static final IllegalStateException NOT_FOUND_CONNECTION_EXCEPTION = new IllegalStateException(FILE_NOT_FOUND_EXCEPTION);
/*     */   
/*     */   private static final String SEPARATOR = "!/";
/*     */   private static final URL EMPTY_JAR_URL;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  55 */       EMPTY_JAR_URL = new URL("jar:", null, 0, "file:!/", new URLStreamHandler()
/*     */       {
/*     */         protected URLConnection openConnection(URL u)
/*     */           throws IOException
/*     */         {
/*  60 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (MalformedURLException ex) {
/*  65 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*  69 */   private static final JarEntryName EMPTY_JAR_ENTRY_NAME = new JarEntryName(new StringSequence(""));
/*     */   
/*     */ 
/*     */   private static final String READ_ACTION = "read";
/*     */   
/*     */ 
/*  75 */   private static final JarURLConnection NOT_FOUND_CONNECTION = notFound();
/*     */   
/*     */   private final JarFile jarFile;
/*     */   
/*     */   private Permission permission;
/*     */   
/*     */   private URL jarFileUrl;
/*     */   
/*     */   private final JarEntryName jarEntryName;
/*     */   
/*     */   private JarEntry jarEntry;
/*     */   
/*     */   private JarURLConnection(URL url, JarFile jarFile, JarEntryName jarEntryName)
/*     */     throws IOException
/*     */   {
/*  90 */     super(EMPTY_JAR_URL);
/*  91 */     this.url = url;
/*  92 */     this.jarFile = jarFile;
/*  93 */     this.jarEntryName = jarEntryName;
/*     */   }
/*     */   
/*     */   public void connect() throws IOException
/*     */   {
/*  98 */     if (this.jarFile == null) {
/*  99 */       throw FILE_NOT_FOUND_EXCEPTION;
/*     */     }
/* 101 */     if ((!this.jarEntryName.isEmpty()) && (this.jarEntry == null)) {
/* 102 */       this.jarEntry = this.jarFile.getJarEntry(getEntryName());
/* 103 */       if (this.jarEntry == null) {
/* 104 */         throwFileNotFound(this.jarEntryName, this.jarFile);
/*     */       }
/*     */     }
/* 107 */     this.connected = true;
/*     */   }
/*     */   
/*     */   public JarFile getJarFile() throws IOException
/*     */   {
/* 112 */     connect();
/* 113 */     return this.jarFile;
/*     */   }
/*     */   
/*     */   public URL getJarFileURL()
/*     */   {
/* 118 */     if (this.jarFile == null) {
/* 119 */       throw NOT_FOUND_CONNECTION_EXCEPTION;
/*     */     }
/* 121 */     if (this.jarFileUrl == null) {
/* 122 */       this.jarFileUrl = buildJarFileUrl();
/*     */     }
/* 124 */     return this.jarFileUrl;
/*     */   }
/*     */   
/*     */   private URL buildJarFileUrl() {
/*     */     try {
/* 129 */       String spec = this.jarFile.getUrl().getFile();
/* 130 */       if (spec.endsWith("!/")) {
/* 131 */         spec = spec.substring(0, spec.length() - "!/".length());
/*     */       }
/* 133 */       if (spec.indexOf("!/") == -1) {
/* 134 */         return new URL(spec);
/*     */       }
/* 136 */       return new URL("jar:" + spec);
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 139 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public JarEntry getJarEntry() throws IOException
/*     */   {
/* 145 */     if ((this.jarEntryName == null) || (this.jarEntryName.isEmpty())) {
/* 146 */       return null;
/*     */     }
/* 148 */     connect();
/* 149 */     return this.jarEntry;
/*     */   }
/*     */   
/*     */   public String getEntryName()
/*     */   {
/* 154 */     if (this.jarFile == null) {
/* 155 */       throw NOT_FOUND_CONNECTION_EXCEPTION;
/*     */     }
/* 157 */     return this.jarEntryName.toString();
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/* 162 */     if (this.jarFile == null) {
/* 163 */       throw FILE_NOT_FOUND_EXCEPTION;
/*     */     }
/* 165 */     if ((this.jarEntryName.isEmpty()) && 
/* 166 */       (this.jarFile.getType() == JarFile.JarFileType.DIRECT)) {
/* 167 */       throw new IOException("no entry name specified");
/*     */     }
/* 169 */     connect();
/*     */     
/*     */ 
/* 172 */     InputStream inputStream = this.jarEntryName.isEmpty() ? this.jarFile.getData().getInputStream() : this.jarFile.getInputStream(this.jarEntry);
/* 173 */     if (inputStream == null) {
/* 174 */       throwFileNotFound(this.jarEntryName, this.jarFile);
/*     */     }
/* 176 */     return inputStream;
/*     */   }
/*     */   
/*     */   private void throwFileNotFound(Object entry, JarFile jarFile) throws FileNotFoundException
/*     */   {
/* 181 */     if (Boolean.TRUE.equals(useFastExceptions.get())) {
/* 182 */       throw FILE_NOT_FOUND_EXCEPTION;
/*     */     }
/*     */     
/* 185 */     throw new FileNotFoundException("JAR entry " + entry + " not found in " + jarFile.getName());
/*     */   }
/*     */   
/*     */   public int getContentLength()
/*     */   {
/* 190 */     long length = getContentLengthLong();
/* 191 */     if (length > 2147483647L) {
/* 192 */       return -1;
/*     */     }
/* 194 */     return (int)length;
/*     */   }
/*     */   
/*     */   public long getContentLengthLong()
/*     */   {
/* 199 */     if (this.jarFile == null) {
/* 200 */       return -1L;
/*     */     }
/*     */     try {
/* 203 */       if (this.jarEntryName.isEmpty()) {
/* 204 */         return this.jarFile.size();
/*     */       }
/* 206 */       JarEntry entry = getJarEntry();
/* 207 */       return entry == null ? -1 : (int)entry.getSize();
/*     */     }
/*     */     catch (IOException ex) {}
/* 210 */     return -1L;
/*     */   }
/*     */   
/*     */   public Object getContent()
/*     */     throws IOException
/*     */   {
/* 216 */     connect();
/* 217 */     return this.jarEntryName.isEmpty() ? this.jarFile : super.getContent();
/*     */   }
/*     */   
/*     */   public String getContentType()
/*     */   {
/* 222 */     return this.jarEntryName == null ? null : this.jarEntryName.getContentType();
/*     */   }
/*     */   
/*     */   public Permission getPermission() throws IOException
/*     */   {
/* 227 */     if (this.jarFile == null) {
/* 228 */       throw FILE_NOT_FOUND_EXCEPTION;
/*     */     }
/* 230 */     if (this.permission == null)
/*     */     {
/* 232 */       this.permission = new FilePermission(this.jarFile.getRootJarFile().getFile().getPath(), "read");
/*     */     }
/* 234 */     return this.permission;
/*     */   }
/*     */   
/*     */   public long getLastModified()
/*     */   {
/* 239 */     if ((this.jarFile == null) || (this.jarEntryName.isEmpty())) {
/* 240 */       return 0L;
/*     */     }
/*     */     try {
/* 243 */       JarEntry entry = getJarEntry();
/* 244 */       return entry == null ? 0L : entry.getTime();
/*     */     }
/*     */     catch (IOException ex) {}
/* 247 */     return 0L;
/*     */   }
/*     */   
/*     */   static void setUseFastExceptions(boolean useFastExceptions)
/*     */   {
/* 252 */     useFastExceptions.set(Boolean.valueOf(useFastExceptions));
/*     */   }
/*     */   
/*     */   static JarURLConnection get(URL url, JarFile jarFile) throws IOException {
/* 256 */     StringSequence spec = new StringSequence(url.getFile());
/* 257 */     int index = indexOfRootSpec(spec, jarFile.getPathFromRoot());
/*     */     int separator;
/* 259 */     while ((separator = spec.indexOf("!/", index)) > 0) {
/* 260 */       JarEntryName entryName = JarEntryName.get(spec.subSequence(index, separator));
/* 261 */       JarEntry jarEntry = jarFile.getJarEntry(entryName.toCharSequence());
/* 262 */       if (jarEntry == null) {
/* 263 */         return notFound(jarFile, entryName);
/*     */       }
/* 265 */       jarFile = jarFile.getNestedJarFile(jarEntry);
/* 266 */       index = separator + "!/".length();
/*     */     }
/* 268 */     JarEntryName jarEntryName = JarEntryName.get(spec, index);
/* 269 */     if ((Boolean.TRUE.equals(useFastExceptions.get())) && (!jarEntryName.isEmpty()) && 
/* 270 */       (!jarFile.containsEntry(jarEntryName.toString()))) {
/* 271 */       return NOT_FOUND_CONNECTION;
/*     */     }
/* 273 */     return new JarURLConnection(url, jarFile, jarEntryName);
/*     */   }
/*     */   
/*     */   private static int indexOfRootSpec(StringSequence file, String pathFromRoot) {
/* 277 */     int separatorIndex = file.indexOf("!/");
/* 278 */     if (separatorIndex < 0) {
/* 279 */       return -1;
/*     */     }
/* 281 */     return separatorIndex + "!/".length() + pathFromRoot.length();
/*     */   }
/*     */   
/*     */   private static JarURLConnection notFound() {
/*     */     try {
/* 286 */       return notFound(null, null);
/*     */     }
/*     */     catch (IOException ex) {
/* 289 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static JarURLConnection notFound(JarFile jarFile, JarEntryName jarEntryName) throws IOException
/*     */   {
/* 295 */     if (Boolean.TRUE.equals(useFastExceptions.get())) {
/* 296 */       return NOT_FOUND_CONNECTION;
/*     */     }
/* 298 */     return new JarURLConnection(null, jarFile, jarEntryName);
/*     */   }
/*     */   
/*     */ 
/*     */   static class JarEntryName
/*     */   {
/*     */     private final StringSequence name;
/*     */     
/*     */     private String contentType;
/*     */     
/*     */ 
/*     */     JarEntryName(StringSequence spec)
/*     */     {
/* 311 */       this.name = decode(spec);
/*     */     }
/*     */     
/*     */     private StringSequence decode(StringSequence source) {
/* 315 */       if ((source.isEmpty()) || (source.indexOf('%') < 0)) {
/* 316 */         return source;
/*     */       }
/* 318 */       ByteArrayOutputStream bos = new ByteArrayOutputStream(source.length());
/* 319 */       write(source.toString(), bos);
/*     */       
/* 321 */       return new StringSequence(AsciiBytes.toString(bos.toByteArray()));
/*     */     }
/*     */     
/*     */     private void write(String source, ByteArrayOutputStream outputStream) {
/* 325 */       int length = source.length();
/* 326 */       for (int i = 0; i < length; i++) {
/* 327 */         int c = source.charAt(i);
/* 328 */         if (c > 127) {
/*     */           try {
/* 330 */             String encoded = URLEncoder.encode(String.valueOf((char)c), "UTF-8");
/*     */             
/* 332 */             write(encoded, outputStream);
/*     */           }
/*     */           catch (UnsupportedEncodingException ex) {
/* 335 */             throw new IllegalStateException(ex);
/*     */           }
/*     */         }
/*     */         else {
/* 339 */           if (c == 37) {
/* 340 */             if (i + 2 >= length)
/*     */             {
/* 342 */               throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */             }
/*     */             
/* 345 */             c = decodeEscapeSequence(source, i);
/* 346 */             i += 2;
/*     */           }
/* 348 */           outputStream.write(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private char decodeEscapeSequence(String source, int i) {
/* 354 */       int hi = Character.digit(source.charAt(i + 1), 16);
/* 355 */       int lo = Character.digit(source.charAt(i + 2), 16);
/* 356 */       if ((hi == -1) || (lo == -1))
/*     */       {
/* 358 */         throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */       }
/* 360 */       return (char)((hi << 4) + lo);
/*     */     }
/*     */     
/*     */     public CharSequence toCharSequence() {
/* 364 */       return this.name;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 369 */       return this.name.toString();
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 373 */       return this.name.isEmpty();
/*     */     }
/*     */     
/*     */     public String getContentType() {
/* 377 */       if (this.contentType == null) {
/* 378 */         this.contentType = deduceContentType();
/*     */       }
/* 380 */       return this.contentType;
/*     */     }
/*     */     
/*     */     private String deduceContentType()
/*     */     {
/* 385 */       String type = isEmpty() ? "x-java/jar" : null;
/* 386 */       type = type != null ? type : URLConnection.guessContentTypeFromName(toString());
/* 387 */       type = type != null ? type : "content/unknown";
/* 388 */       return type;
/*     */     }
/*     */     
/*     */     public static JarEntryName get(StringSequence spec) {
/* 392 */       return get(spec, 0);
/*     */     }
/*     */     
/*     */     public static JarEntryName get(StringSequence spec, int beginIndex) {
/* 396 */       if (spec.length() <= beginIndex) {
/* 397 */         return JarURLConnection.EMPTY_JAR_ENTRY_NAME;
/*     */       }
/* 399 */       return new JarEntryName(spec.subSequence(beginIndex));
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\org\springframework\boot\loader\jar\JarURLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */