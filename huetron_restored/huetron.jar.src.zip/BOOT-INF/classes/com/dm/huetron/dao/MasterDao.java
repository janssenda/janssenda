/*    */ package com.dm.huetron.dao;
/*    */ 
/*    */ import com.dm.huetron.exception.SQLUpdateException;
/*    */ import com.dm.huetron.model.Light;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.dao.DataIntegrityViolationException;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.stereotype.Component;
/*    */ import org.springframework.transaction.annotation.Transactional;
/*    */ 
/*    */ 
/*    */ @Component
/*    */ public class MasterDao
/*    */ {
/*    */   private JdbcTemplate jdbcTemplate;
/*    */   private static final String ADD_LIGHT_QUERY = "INSERT INTO lights (Title, Description) VALUES(?,?)";
/*    */   private static final String GET_LIGHTS_QUERY = "SELECT * FROM lights";
/*    */   
/*    */   @Autowired
/*    */   public MasterDao(JdbcTemplate jdbcTemplate)
/*    */   {
/* 23 */     this.jdbcTemplate = jdbcTemplate;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<Light> getAllLights()
/*    */   {
/* 35 */     return this.jdbcTemplate.query("SELECT * FROM lights", new MasterDao.LightMapper(null));
/*    */   }
/*    */   
/*    */   @Transactional
/*    */   public Light addLight(Light light) throws SQLUpdateException
/*    */   {
/*    */     try
/*    */     {
/* 43 */       if (this.jdbcTemplate.update("INSERT INTO lights (Title, Description) VALUES(?,?)", new Object[] { light.getTitle(), light.getDescription() }) > 0) {
/* 44 */         light.setLightID((String)this.jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", String.class));
/* 45 */         return light;
/*    */       }
/*    */       
/* 48 */       throw new SQLUpdateException("There was a problem adding the data or row does not exist");
/*    */     }
/*    */     catch (SQLUpdateException|DataIntegrityViolationException e) {
/* 51 */       throw new SQLUpdateException(e.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\dao\MasterDao.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */