/*     */ package com.dm.huetron.model;
/*     */ 
/*     */ public class Light
/*     */ {
/*     */   private String lightID;
/*     */   private String title;
/*     */   private String description;
/*     */   private String hue;
/*     */   private String brt;
/*     */   private String sat;
/*     */   private boolean state;
/*     */   
/*     */   public Light() {
/*  14 */     this.lightID = "";
/*  15 */     this.description = "";
/*  16 */     this.title = "";
/*  17 */     this.brt = "0";
/*  18 */     this.sat = "0";
/*  19 */     this.hue = "0";
/*  20 */     this.state = false;
/*     */   }
/*     */   
/*     */   public String getLightID() {
/*  24 */     return this.lightID;
/*     */   }
/*     */   
/*     */   public void setLightID(String lightID) {
/*  28 */     this.lightID = lightID;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/*  32 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(String title) {
/*  36 */     this.title = title;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  40 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  44 */     this.description = description;
/*     */   }
/*     */   
/*     */   public String getHue() {
/*  48 */     return this.hue;
/*     */   }
/*     */   
/*     */   public void setHue(String hue) {
/*  52 */     this.hue = hue;
/*     */   }
/*     */   
/*     */   public String getBrt() {
/*  56 */     return this.brt;
/*     */   }
/*     */   
/*     */   public void setBrt(String brt) {
/*  60 */     this.brt = brt;
/*     */   }
/*     */   
/*     */   public String getSat() {
/*  64 */     return this.sat;
/*     */   }
/*     */   
/*     */   public void setSat(String sat) {
/*  68 */     this.sat = sat;
/*     */   }
/*     */   
/*     */   public boolean isState() {
/*  72 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(boolean state) {
/*  76 */     this.state = state;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/*  81 */     if (this == o) return true;
/*  82 */     if ((o == null) || (getClass() != o.getClass())) { return false;
/*     */     }
/*  84 */     Light light = (Light)o;
/*     */     
/*  86 */     if (this.state != light.state) return false;
/*  87 */     if (this.lightID != null ? !this.lightID.equals(light.lightID) : light.lightID != null) return false;
/*  88 */     if (this.title != null ? !this.title.equals(light.title) : light.title != null) return false;
/*  89 */     if (this.description != null ? !this.description.equals(light.description) : light.description != null) return false;
/*  90 */     if (this.hue != null ? !this.hue.equals(light.hue) : light.hue != null) return false;
/*  91 */     if (this.brt != null ? !this.brt.equals(light.brt) : light.brt != null) return false;
/*  92 */     return light.sat == null ? true : this.sat != null ? this.sat.equals(light.sat) : false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  97 */     int result = this.lightID != null ? this.lightID.hashCode() : 0;
/*  98 */     result = 31 * result + (this.title != null ? this.title.hashCode() : 0);
/*  99 */     result = 31 * result + (this.description != null ? this.description.hashCode() : 0);
/* 100 */     result = 31 * result + (this.hue != null ? this.hue.hashCode() : 0);
/* 101 */     result = 31 * result + (this.brt != null ? this.brt.hashCode() : 0);
/* 102 */     result = 31 * result + (this.sat != null ? this.sat.hashCode() : 0);
/* 103 */     result = 31 * result + (this.state ? 1 : 0);
/* 104 */     return result;
/*     */   }
/*     */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\model\Light.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */