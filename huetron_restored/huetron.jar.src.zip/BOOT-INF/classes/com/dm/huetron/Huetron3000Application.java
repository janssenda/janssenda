/*    */ package com.dm.huetron;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.boot.autoconfigure.SpringBootApplication;
/*    */ 
/*    */ @SpringBootApplication
/*    */ public class Huetron3000Application
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 11 */     SpringApplication.run(Huetron3000Application.class, args);
/*    */   }
/*    */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\Huetron3000Application.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */