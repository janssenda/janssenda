/*    */ package com.dm.huetron.exception;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ 
/*    */ @org.springframework.web.bind.annotation.ResponseStatus(HttpStatus.NOT_FOUND)
/*    */ public class ResourceNotFoundException extends RuntimeException
/*    */ {
/*    */   private String resourceName;
/*    */   private String fieldName;
/*    */   private Object fieldValue;
/*    */   
/*    */   public ResourceNotFoundException(String resourceName, String fieldName, Object fieldValue)
/*    */   {
/* 14 */     super(String.format("%s not found with %s : '%s'", new Object[] { resourceName, fieldName, fieldValue }));
/* 15 */     this.resourceName = resourceName;
/* 16 */     this.fieldName = fieldName;
/* 17 */     this.fieldValue = fieldValue;
/*    */   }
/*    */   
/*    */   public String getResourceName() {
/* 21 */     return this.resourceName;
/*    */   }
/*    */   
/*    */   public String getFieldName() {
/* 25 */     return this.fieldName;
/*    */   }
/*    */   
/*    */   public Object getFieldValue() {
/* 29 */     return this.fieldValue;
/*    */   }
/*    */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\exception\ResourceNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */