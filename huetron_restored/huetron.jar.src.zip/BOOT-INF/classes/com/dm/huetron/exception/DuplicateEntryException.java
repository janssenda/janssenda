/*   */ package com.dm.huetron.exception;
/*   */ 
/*   */ import org.springframework.http.HttpStatus;
/*   */ 
/*   */ @org.springframework.web.bind.annotation.ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Duplicate")
/*   */ public class DuplicateEntryException extends Exception
/*   */ {
/*   */   public DuplicateEntryException(String message) {
/* 9 */     super(message);
/*   */   }
/*   */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\exception\DuplicateEntryException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */