/*    */ package com.dm.huetron.controller;
/*    */ 
/*    */ import com.dm.huetron.dao.MasterDao;
/*    */ import com.dm.huetron.exception.SQLUpdateException;
/*    */ import com.dm.huetron.model.Light;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*    */ import org.springframework.web.bind.annotation.RequestBody;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ import org.springframework.web.bind.annotation.ResponseBody;
/*    */ import org.springframework.web.bind.annotation.RestController;
/*    */ 
/*    */ 
/*    */ @RestController
/*    */ public class ApiController
/*    */ {
/*    */   private MasterDao dao;
/*    */   
/*    */   @Autowired
/*    */   public ApiController(MasterDao dao)
/*    */   {
/* 24 */     this.dao = dao;
/*    */   }
/*    */   
/*    */   @ResponseBody
/*    */   @RequestMapping(value={"/lights", "/lights/"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
/*    */   public List<Light> getLights(HttpServletRequest req)
/*    */   {
/* 31 */     return this.dao.getAllLights();
/*    */   }
/*    */   
/*    */   @RequestMapping(value={"/lights", "/lights/"}, method={org.springframework.web.bind.annotation.RequestMethod.POST})
/*    */   @ResponseBody
/*    */   @ExceptionHandler
/*    */   public Light addLight(@RequestBody Light light) throws SQLUpdateException
/*    */   {
/* 39 */     return this.dao.addLight(light);
/*    */   }
/*    */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\controller\ApiController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */