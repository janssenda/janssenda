/*    */ package com.dm.huetron.controller;
/*    */ 
/*    */ import org.springframework.stereotype.Controller;
/*    */ import org.springframework.ui.Model;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ 
/*    */ 
/*    */ @Controller
/*    */ public class WebController
/*    */ {
/*    */   @RequestMapping({"/index", "/"})
/*    */   public String home1(Model model)
/*    */   {
/* 14 */     return "index";
/*    */   }
/*    */ }


/* Location:              G:\Repositories\thenewcarag\huetron\huetron.jar!\BOOT-INF\classes\com\dm\huetron\controller\WebController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */