/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dm.vendingmashine.controller;

import com.dm.vendingmashine.dao.FileIOException;
import com.dm.vendingmashine.dto.Money;
import com.dm.vendingmashine.servicelayer.VendingMashineService;
import com.dm.vendingmashine.ui.VendingMashineView;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author danimaetrix
 */
public class VendingMashineController {

    private final Money userMoney;

    // Dependency Injection
    VendingMashineService service;
    VendingMashineView view;

    //service.vtesting ();
    public VendingMashineController(VendingMashineView view, VendingMashineService service) {
        this.service = service;
        this.view = view;
        this.userMoney = new Money(BigDecimal.valueOf(0));
    }

    // Main program loop
    public void run() {
        String errmsg = service.checkForFileIOErrors();

        if (errmsg != null) {
            view.displayExceptionMessage(errmsg);
        } else {

            drinkMenuSelection(userMoney);
            view.showChange(userMoney);

            try {
                service.updateInventory();
            } catch (FileIOException e) {
                view.displayExceptionMessage("Error updating inventory file: " + e.getMessage());
            }
        }

        exitProgram();

    }
    // End main program loop
    // Main drink menu screen

    private boolean drinkMenuSelection(Money userMoney) {
        boolean repeat = true;
        List<String[]> priceList;

        while (repeat) {
            priceList = service.returnPriceArrayWithStatus();
            view.cls();
            view.generateMenu(priceList);
            int choice = view.getUserDrinkSelection(userMoney, priceList.size());

            switch (choice) {
                case 0:
                    return false;
                case 1:
                    view.userAddMoney(userMoney);
                    break;
                default:
                    String name = priceList.get(choice - 2)[0];
                    if (!service.validateMoney(userMoney, name)) {
                        view.insufficientFundsBanner();
                    } else if (service.isSoldOut(name)) {
                        view.soldOutBanner();
                    } else {
                        view.showTheProduct(service.getProduct(name));
                        service.vendProduct(name);
                        userMoney = service.calculateChange(userMoney, name);
                    }
                    view.waitOnUser();
                    break;
            }
        }

        return true;
    }

    private void exitProgram() {
        view.showExitMessage();
    }

}
